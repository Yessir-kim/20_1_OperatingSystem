#include<stdio.h>

int main()
{
	char name[10] ;

	printf("Input your name : ") ;
	scanf("%s", name) ;

	printf("Nice to meet you %s!\n", name) ;

	return 0 ;
}
