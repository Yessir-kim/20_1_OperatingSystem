#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#define MAX_CMD 2048
#define MAX_ARG 256

void ParseCommand(char *command, int *argc, char *argv[]);

int main()
{
	char command[MAX_CMD];
	command[0] = command[MAX_CMD-1] = 0; // for safety

	int argc = 0;
	char *argv[MAX_ARG] = { NULL };

	while(1){
		printf("$ ");
		fgets(command, MAX_CMD - 1, stdin);
		command[strlen(command)-1] = 0; // trim \r
	
		if(strcmp(command, "quit") == 0 || strcmp(command, "exit") == 0)
			break;

		ParseCommand(command, &argc, argv);
		/*		
		printf("argc = %d\n", argc);
		for(int i = 0; i < argc; i++)
			printf("argv[%d] = %s\n", i, argv[i]);
		printf("argv[%d] = %p\n", argc, argv[argc]); // argv[argc] must be NULL
		*/
		pid_t child_pid = fork() ;
		
		if(child_pid < 0)
		{
			fprintf(stderr,"Fork failed\n") ;
			exit(-1) ;
		}
		else if(child_pid == 0) execvp(argv[0],argv) ;
		else wait(NULL) ;
	}
		printf("Bye!\n");

		return 0;
}

void ParseCommand(char *command, int *argc, char *argv[])
{
	int argv_idx = 0 ;
	int com_idx = 0 ;
	int flag = 1 ;
	while(command[com_idx] != '\0')
	{	
		flag = 1 ;
		if(command[com_idx] == ' ')	while(strlen(command) > com_idx+1 && command[com_idx+1] == ' ') com_idx++ ; // Pass Space 
		else if(command[com_idx] == '\t') while(strlen(command) > com_idx+1 && command[com_idx+1] == '\t') com_idx++ ; // Pass Tap
		else if(command[com_idx] == '\"' || command[com_idx] == '\'')
		{
			command[com_idx] = 0 ;
			
			*(argv+argv_idx) = &command[com_idx+1] ;
			argv_idx++ ;

			while(command[com_idx] != '\"' && command[com_idx] != '\'') com_idx++ ;
			command[com_idx] = 0 ;
		}
		else
		{
			*(argv+argv_idx) = &command[com_idx] ;
			argv_idx++ ;
			
			while(command[com_idx] != '\0' && command[com_idx] != ' ' && command[com_idx] != '\t')
			{
				com_idx++ ;
				if(command[com_idx] == '\'' || command[com_idx] == '\"')
				{
					flag = 0 ;
					break ;
				}
			}
			if(flag) command[com_idx] = 0 ;
		}
		
		if(flag) com_idx++ ;
	}

	*(argv+argv_idx) = NULL ;
	*argc = argv_idx ;
}
