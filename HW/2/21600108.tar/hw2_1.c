#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define BUFFER_SIZE 512

// global variables
char buffer[BUFFER_SIZE];
int buffer_size = 0;
int buffer_pos = 0;

int ReadTextLine(int fd, char str[], int max_len) ;

int main(int argc, char *argv[])
{
	
	int fc, fm, fw ;
	char str[100] ;
	char cpu[50] ;
	int n_cpu ;
	int t_mem ;
	float avg1, avg5, avg15 ;


	fc = open("/proc/cpuinfo",O_RDONLY) ; // succ == 1 or fail == -1
	fm = open("/proc/meminfo",O_RDONLY) ;
	fw = open("/proc/loadavg",O_RDONLY) ;
	
	for(int i = 0 ; i < 13 ; i++)
	{
		ReadTextLine(fc,str,100) ;
		if(i == 4)	sscanf(str,"%*s %*s %*s %[^'\n']",cpu) ;
		if(i == 12) sscanf(str,"%*s %*s %*s %d",&n_cpu) ;
	}
	
	ReadTextLine(fm,str,100) ;
	sscanf(str,"%*s %d",&t_mem) ;

	ReadTextLine(fw,str,100) ;
	sscanf(str,"%f %f %f",&avg1,&avg5,&avg15) ;

	printf("# of processor cores = %d\n",n_cpu) ;
	printf("CPU model = %s\n",cpu) ;
	printf("MemTotal = %d\n",t_mem) ;
	printf("loadavg1 = %f, loadavg5 = %f, loadavg15 = %f\n",avg1,avg5,avg15) ;

	close(fc) ;
	close(fm) ;
	close(fw) ;
}

int ReadTextLine(int fd, char str[], int max_len)
{
	int i = 0 ;
	int j = 0 ;
	int ret = 0 ;
	
	// if current position is 0, reset buffer size and pos
	if(lseek(fd, 0, SEEK_CUR) == 0) buffer_pos = buffer_size = 0;

	while(j < max_len - 1){
		if(buffer_pos == buffer_size){
			buffer[0] = 0;
			buffer_size = read(fd, buffer, BUFFER_SIZE);
			buffer_pos = 0;
		}

		if(buffer_size == 0){
			if(j == 0) ret = EOF;
			break;
		}
		while(j < max_len - 2 && buffer_pos < buffer_size){
			str[j++] = buffer[buffer_pos++];
			if(str[j - 1] == '\0' || str[j - 1] == 10){
				j--; // to remove CR
				max_len = j; // to terminate outer loop
				break; // break inner loop
			}
		}
	}
	
	str[j] = 0;
	
	return ret;
}

